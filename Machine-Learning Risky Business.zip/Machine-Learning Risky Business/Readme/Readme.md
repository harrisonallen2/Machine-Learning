﻿**Risky Business**

![credit-risk.jpg](Aspose.Words.dcfaec04-e70d-49f8-ac59-85bd7541f22f.001.jpeg)

Background


Mortgages, student and auto loans, and debt consolidation are just a fewexamples of credit and loans that people seek online. Peer-to-peerlending services such as Loans Canada and Mogo let investors loan peoplemoney without using a bank. However, because investors always want tomitigate risk, a client has asked that you help them predict credit riskwith machine learning techniques.

Credit risk is an inherently imbalanced classification problem (thenumber of good loans is much larger than the number of at-risk loans),so you will need to employ different techniques for training andevaluating models with imbalanced classes. You will use theimbalanced-learn and Scikit-learn libraries to build and evaluate modelsusing the two following techniques:

Resampling

Process:

1.Read the CSV into a DataFrame.

2.Split the data into Training and Testing sets.

3.Scale the training and testing data using the StandardScaler from

sklearn.preprocessing.

4.Use the provided code to run a Simple Logistic Regression:

oFit the logistic regression classifier.

oCalculate the balanced accuracy score.

oDisplay the confusion matrix.

oPrint the imbalanced classification report.

Next:

5.Oversample the data using the Naive Random Oversampler and SMOTEalgorithms.

6.Undersample the data using the Cluster Centroids algorithm.

7.Over- and undersample using a combination SMOTEENN algorithm.

For each of the above:

1.Train a logistic regression classifier from sklearn.linear\_modelusing the resampled data.

2.Calculate the balanced accuracy score from sklearn.metrics.

3.Display the confusion matrix from sklearn.metrics.

4.Print the imbalanced classification report from

imblearn.metrics.

Questions and Conclusions:

**Which model had the best balanced accuracy score?**

1.Simple Logistic Regression balanced accuracy score0.9543211898288821

2.Naive Random Oversampling balanced accuracy score0.9934649587814939\*\*

3.SMOTE Oversampling balanced accuracy score 0.9936781215845847\*\*

4.Undersampling balanced accuracy score 0.8099934699520943\*\*

5.Combination balanced accuracy score 0.9935715401830394\*\*

**The best balanced accuracy score was SMOTE but it is notable thatSMOTE, Naive and Combination all had scores of higher than the simplelogistic regression.**

**Which model had the best recall score?**

1.Simple Logistic Regression recall score .99

2.Naive Random Oversampling balanced recallscore .99

3.SMOTE Oversampling balanced recall score .99

4.Undersampling balanced recall score .64

5.Combination balanced recall score .99

**All of the models with the exception of undersampling have a recallscore of .99**

**Which model had the best geometric mean score?** 

\1. Simple LogisticRegression geo score .95 2. Naive Random Oversampling geo score .99 3.SMOTE Oversampling geo score .99 4. Undersampling geo score .79 5.Combination geo score .99

**Naive random, SMOTE and combination all have a geo score of .99**

Ensemble Learning

Process:

1.Read the data into a DataFrame using the provided starter code.

2.Split the data into training and testing sets.

3.Scale the training and testing data using the StandardScaler from

sklearn.preprocessing.

Then, for each model:

1.Train the model using the quarterly data from LendingClub provided

in the Resource folder.

2.Calculate the balanced accuracy score from sklearn.metrics.

3.Display the confusion matrix from sklearn.metrics.

4.Generate a classification report using the

imbalanced\_classification\_report from imbalanced learn.

5.For the balanced random forest classifier only, print the featureimportance sorted in descending order 

(most important feature toleast important) along with the feature score.

Questions and Conclusions:

-Which model had the best balanced accuracy score?

` `**Random Forest accuracy score .78** **Easy ensemble accuracy scoreof .93** **Easy ensemble has the best balanced accuracy score.**

-Which model had the best recall score?

` `**Random Forest recall score .87** **Easy ensemble recall score of.94** **Easy ensemble has the best recall score.**

-Which model had the best geometric mean score?

` `**Random Forest geo mean score .78** **Easy ensemble geo mean scoreof .93** **Easy ensemble has the best geo mean score.**

-What are the top three features?

` `**total\_rec\_prncp 0.078768** **total\_pymnt 0.058838total\_pymnt\_inv 0.056256**

